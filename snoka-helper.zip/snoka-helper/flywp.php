<?php
/**
 * Plugin Name: Snoka Helper
 * Plugin URI: https://www.snoka.ca
 * Description: Helper plugin for Snoka Media managed WordPress sites. Powered by FlyWP.
 * Version: 1.9.1
 * Author: Snoka Media
 * Author URI: https://www.snoka.ca
 * License: Proprietary
 * ponytail: Proprietary license — not distributed on WordPress.org, Plugin Check warning ignored per project policy.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require __DIR__ . '/vendor/autoload.php';

use WeDevs\WpUtils\ContainerTrait;
use WeDevs\WpUtils\HookTrait;
use WeDevs\WpUtils\SingletonTrait;

/**
 * Main FlyWP Class.
 *
 * @var admin   FlyWP\Admin
 * @var rest    FlyWP\Api
 * @var fastcgi FlyWP\Fastcgi_Cache
 * @var router  FlyWP\Router
 *
 * @class FlyWP
 */
final class FlyWP_Plugin {

    use SingletonTrait;
    use ContainerTrait;
    use HookTrait;

    /**
     * Plugin version.
     *
     * @var string
     */
    public $version = '1.9.1';

    /**
     * The reseller's brand, read once per request.
     *
     * @var FlyWP\Brand|null
     */
    private $brand = null;

    /**
     * Plugin Constructor.
     *
     * @return void
     */
    private function __construct() {
        $this->define_constants();

        $this->add_action( 'plugins_loaded', 'init_plugin' );
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
    }

    /**
     * Define plugin constants.
     *
     * @return void
     */
    private function define_constants() {
        define( 'FLYWP_VERSION', $this->version );
        define( 'FLYWP_PLUGIN_FILE', __FILE__ );
        define( 'FLYWP_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
        define( 'FLYWP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
        define( 'FLYWP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

        if ( ! defined( 'FLYWP_API_KEY' ) ) {
            define( 'FLYWP_API_KEY', '' );
        }

        if ( ! defined( 'FLYWP_LOGIN_PUBLIC_KEY' ) ) {
            define( 'FLYWP_LOGIN_PUBLIC_KEY', '' );
        }

        if ( ! defined( 'FLYWP_BRAND' ) ) {
            define( 'FLYWP_BRAND', '' );
        }

        if ( ! defined( 'SNOKA_ADMIN_USER' ) ) {
            define( 'SNOKA_ADMIN_USER', '' );
        }
    }

    /**
     * Plugin activation hook.
     *
     * @return void
     */
    public function activate() {
        $router = new FlyWP\Router();
        $router->register_routes();

        flush_rewrite_rules( false );

        FlyWP\StaticSite\Bootstrap::install();
    }

    /**
     * Plugin deactivation hook.
     *
     * @return void
     */
    public function deactivate() {
        $timestamp = wp_next_scheduled( FlyWP\Api\UpdatesData::CRON_HOOK );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, FlyWP\Api\UpdatesData::CRON_HOOK );
        }
    }

    /**
     * Initialize plugin.
     *
     * @return void
     */
    public function init_plugin() {
        // Loaded ahead of the API-key gate below, as it does not use the API key. It answers
        // one POST path and does nothing on any other request.
        new FlyWP\Frontend\MagicLogin();
        // Also ahead of the gate: the Plugins list and core's update email read the header anyway.
        new FlyWP\Branding();
        // Also ahead of the gate: a full disk refuses uploads whether or not the key is set.
        new FlyWP\Uploads();

        // The static site CLI commands do not use the API key.
        FlyWP\StaticSite\Bootstrap::register_cli();

        if ( ! $this->has_key() ) {
            $this->add_action( 'admin_notices', 'admin_notice' );

            return;
        }

        if ( is_admin() ) {
            $this->admin = new FlyWP\Admin();
        } else {
            $this->frontend = new FlyWP\Frontend();
        }

        $this->router       = new FlyWP\Router();
        $this->rest         = new FlyWP\Api();
        $this->fastcgi      = new FlyWP\Fastcgi_Cache();
        $this->opcache      = new FlyWP\Opcache();
        $this->flyapi       = new FlyWP\FlyApi();
        $this->email        = new FlyWP\Email();
        $this->optimize     = new FlyWP\Optimizations();
        $this->litespeed    = new FlyWP\Litespeed();
        $this->updates_data = new FlyWP\Api\UpdatesData();
        $this->static_site  = new FlyWP\StaticSite\Bootstrap();
    }

    /**
     * Show admin notice if API key is not set.
     *
     * @return void
     */
    public function admin_notice() {
        if ( ! FlyWP\Visibility::can_see() ) {
            return;
        }

        /* translators: %s: the plugin's name */
        $message = sprintf( __( 'Missing %s API key, plugin requires an API key.', 'flywp' ), $this->brand()->name() );

        echo '<div class="notice notice-error"><p>' . esc_html( $message ) . '</p></div>';
    }

    /**
     * Check if API key is set.
     *
     * @return bool
     */
    public function has_key() {
        return FLYWP_API_KEY !== '';
    }

    /**
     * Get API key.
     *
     * @return string
     */
    public function get_key() {
        return FLYWP_API_KEY;
    }

    /**
     * Public key used to verify magic-login tokens.
     *
     * Set as a constant on classic WordPress. On Bedrock it may only be present in the
     * environment, so fall back to `getenv()`.
     *
     * @return string
     */
    public function get_login_public_key() {
        if ( FLYWP_LOGIN_PUBLIC_KEY !== '' ) {
            return FLYWP_LOGIN_PUBLIC_KEY;
        }

        $from_env = getenv( 'FLYWP_LOGIN_PUBLIC_KEY' );

        return $from_env === false ? '' : $from_env;
    }

    /**
     * The brand of the reseller who hosts this site, if one does. Without one, FlyWP.
     *
     * Set as a constant on classic WordPress. On Bedrock it may only be present in the
     * environment, so fall back to `getenv()`.
     *
     * @return FlyWP\Brand
     */
    public function brand() {
        if ( $this->brand === null ) {
            $value = FLYWP_BRAND !== '' ? FLYWP_BRAND : getenv( 'FLYWP_BRAND' );

            // A Bedrock that loads its .env without `putenv()` has it in `$_ENV` or `$_SERVER` only.
            if ( $value === false || $value === '' ) {
                $value = isset( $_ENV['FLYWP_BRAND'] ) ? $_ENV['FLYWP_BRAND'] : ( isset( $_SERVER['FLYWP_BRAND'] ) ? sanitize_text_field( wp_unslash( $_SERVER['FLYWP_BRAND'] ) ) : '' );
            }

            $this->brand = FlyWP\Brand::decode( $value );
        }

        return $this->brand;
    }
}

/**
 * Returns the main instance of FlyWP to prevent the need to use globals.
 *
 * @return FlyWP_Plugin
 */
function flywp() {
    return FlyWP_Plugin::instance();
}

// take off
flywp();
